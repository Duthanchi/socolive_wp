<?php
 #if at first you don't succeed, try, try agian.