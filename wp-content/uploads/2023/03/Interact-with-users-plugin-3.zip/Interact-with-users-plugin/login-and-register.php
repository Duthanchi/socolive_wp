<?php
/*
Plugin Name: Registration, Login and Chat Plugin
Description: A plugin that adds user registration, login and chat functionality to WordPress.
Version: 1.0
Author: Luke
Author URI: 
License: GPL2
*/

function login_register_plugin_scripts() {
    // Enqueue plugin stylesheet
    wp_enqueue_style( 'login_register_plugin-style', plugin_dir_url( __FILE__ ) . 'assets/css/style.css' );
    // Enqueue plugin JavaScript
    wp_enqueue_script( 'login-register-plugin-script-header', plugin_dir_url( __FILE__ ) . 'assets/js/header.js', array('jquery'), '1.0', true );
    wp_enqueue_script( 'login-register-plugin-scrip-utils', plugin_dir_url( __FILE__ ) . 'assets/js/utils.js', array('jquery'), '1.0', true );
}
add_action( 'wp_enqueue_scripts', 'login_register_plugin_scripts' );


// Add registration and login forms to WordPress pages
function soco_registration_form() {
    $output = '';

    // Registration form
    $output .= '<div class="register-window header-window" hidden="">';
    $output .= '<img class="close"src="<?php echo get_template_directory_uri(); ?>/assets/images/close.png">>';
    $output .= '<div class="window-inner input-container">';
    $output .= '<div class="form"><input type="password" autocomplete="new-password" hidden="">';

    $output .= '<div class="form-title">Đăng ký</div>';
    $output .= '<div class="phone-box">';

    $output .= '<div class="input-group">';
    $output .= '<div class="country-code-box"><span class="country-code">+84</span>';

    $output .= '<div class="triangle"></div>';
    $output .= '</div>';
    $output .= '<div class="country-code-list float-clear" hidden="" style="display: none;">';
    $output .= '<ul>';
    $output .= '<li class="country-code-title"><span>A</span></li>';
    $output .= '<li class="country-code-item"><span class="left">Austria</span><span class="right">+43</span></li>';
    $output .= '<li class="country-code-item"><span class="left">Argentina</span><span class="right">+54</span></li>';
    $output .= '<li class="country-code-item"><span class="left">Australia</span><span class="right">+61</span></li>';
    $output .= '<li class="country-code-item"><span class="left">Afghanistan</span><span class="right">+93</span></li>';
    $output .= '<li class="country-code-item"><span class="left">Algeria</span><span class="right">+213</span></li>';
    $output .= '</ul>';
    $output .= '</div><input class="input-phone" i18n-placeholder="请输入手机号码" placeholder="Nhập số điện thoại" type="tel" maxlength="11">';
    $output .= '</div>';
    $output .= '<div class="error-tip"><span hidden="">Định dạng sai số điện thoại(vd: 987654321)</span></div>';
    $output .= '</div>';
    $output .= '<div class="verify-box" hidden="">';
    $output .= '<div class="input-group"><img class="icon" src="<?php echo get_template_directory_uri(); ?>/assets/images/password.svg"> ';
    $output .= '<input class="input-verify" i18n-placeholder="获取并输入验证码" placeholder="Nhận và nhập mã xác minh" type="tel" maxlength="4">';
    $output .= '<div class="btn-verify"><span class="verify-text" i18n-text="获取验证码">Nhận mã xác minh</span></div>';
    $output .= '</div>';
    $output .= '<div class="error-tip"><span i18n-text="请输入4位验证码" hidden="">Nhập 4 ký tự mã xác minh</span></div>';
    $output .= '</div>';
    $output .= '<div class="check-box" hidden="">';
    $output .= '<div class="input-group"><img class="icon" src="<?php echo get_template_directory_uri(); ?>/assets/images/password.svg">';
    $output .= '<input= class="input-check" i18n-placeholder="请输入图片上的验证码" placeholder="Nhập mã xác minh trong hình" type="text" maxlength="5">';
    $output .= '<img class="check-img" src="https://socolive10.tv/">';
    $output .= '</div>';
    $output .= '<div class="error-tip"><span i18n-text="请输入5位验证码" hidden="">Nhập 5 ký tự mã xác minh</span></div>';
    $output .= '</div>';
    $output .= '<div class="or" style="display:none">Hoặc</div>';
    $output .= '<div class="account-box">';
    $output .= '<div class="input-group"><img class="icon" src="<?php echo get_template_directory_uri(); ?>/assets/images/user.svg">';
    $output .= '<input class="input-account" type="text" placeholder="Nhập tên đăng nhập" required=""></div>';
    $output .= '<div class="error-tip"><span hidden="">Nhập tên đăng nhập</span></div>';
    $output .= '</div>';
    $output .= '<div class="captcahr-box" hidden="">';
    $output .= '<div class="input-group"><img class="icon" src="<?php echo get_template_directory_uri(); ?>/assets/images/password.svg">';
    $output .= '<input class="input-check" i18n-placeholder="请输入图片上的验证码" placeholder="Nhập mã xác minh trong hình" type="text" maxlength="5">';
    $output .= '<img class="check-img" src="https://socolive10.tv/"></div>';
    $output .= '<div class="error-tip"><span i18n-text="请输入5位验证码" hidden="">Nhập 5 ký tự mã xác minh</span></div>';
    $output .= '</div>';
    $output .= '<div class="nickname-box">';
    $output .= '<div class="input-group"><img class="icon" src="<?php echo get_template_directory_uri(); ?>/assets/images/user.svg">';
    $output .= '<input class="input-nickname" i18n-placeholder="请输入用户名" placeholder="Đặt biệt danh" type="text" maxlength="15"></div>';
    $output .= '<div class="error-tip"><span i18n-text="请输入2~15位用户名" hidden="">Nhập 2~15 ký tự đăng nhập</span></div>';
    $output .= '</div>';
    $output .= '<div class="password-box">';
    $output .= '<div class="input-group"><img class="icon" src="<?php echo get_template_directory_uri(); ?>/assets/images/password.svg">';
    $output .= '<input class="input-password" type="password" placeholder="Nhập mật khẩu" required="">';
    $output .= '<div class="eye"><i class="iconfont ali-zhenyan" hidden=""></i> <i class="iconfont ali-biyan"></i>';
    $output .= '</div>';
    $output .= '</div>';
    $output .= '<div class="error-tip"><span hidden="">Nhập mật khẩu</span></div>';
    $output .= '</div>';
    $output .= '<div class="bottom">';
    $output .= '<div class="left-btn"><span class="login-jump">Đăng nhập</span></div>';
    $output .= '<input class="submit right-submit" type="submit" value="Đăng ký">';
    $output .= ' </div>';
    $output .= '</div>';
    $output .= '</section>';
    $output .= '</div>';
    $output .= '</div>';
    return $output;
}
add_shortcode( 'soco-user-forms-register', 'soco_registration_form' );




function soco_login_form() {
    $output = '';

    // Registration form
    $output .= '<div class="login-window header-window" hidden="">';
    $output .= '<img class="close" src="<?php echo get_template_directory_uri(); ?>/assets/images/close.png">';
    $output .= '<div class="window-inner">';
    $output .= '<section class="content type-content">';
    $output .= '<div class="form"><input type="password" autocomplete="new-password" hidden="">';
    $output .= '<div class="form-title">Đăng nhập</div>';
    $output .= '<div class="phone-box">';
    $output .= '<div class="input-group">';
    $output .= '<div class="country-code-box"><span class="country-code">+84</span>';
    $output .= '<div class="triangle"></div>';
    $output .= '</div>';
    $output .= '<div class="<div class="country-code-list float-clear" hidden="" style="display: none;">"></div>';
    $output .= '<ul>';
    $output .= '<li class="country-code-title"><span>A</span></li>';
    $output .= '<li class="country-code-item"><span class="left">Austria</span><span class="right">+43</span></li>';
    $output .= '<li class="country-code-item"><span class="left">Austria</span><span class="right">+43</span></li>';
    $output .= '</ul>';
    $output .= ' </div><input class="input-phone" i18n-placeholder="请输入手机号码" placeholder="Nhập số điện thoại" type="tel" maxlength="11">';
    $output .= '</div>';
    $output .= '<div class="error-tip"><span hidden="">Định dạng sai số điện thoại(vd: 987654321)</span></div>';
    $output .= '</div>';
    $output .= '<div class="or">Hoặc</div>';
    $output .= '<div class="account-box">';
    $output .= '<div class="input-group">';
    $output .= '<img class="icon" src="<?php echo get_template_directory_uri(); ?>/assets/images/user.svg">';
    $output .= '<input class="input-account" type="text" placeholder="Nhập tên đăng nhập" required=""></div>';
    $output .= '<div class="error-tip"><span hidden="">Nhập tên đăng nhập</span></div>';
    $output .= '</div>';
    $output .= '<div class="password-box">';
    $output .= '<div class="input-group">';
    $output .= '<img class="icon" src="<?php echo get_template_directory_uri(); ?>/assets/images/password.svg">';
    $output .= '<input class="input-password" type="password" placeholder="Nhập mật khẩu" required="">';
    $output .= '<div class="eye"><i class="iconfont ali-zhenyan" hidden=""></i> <i class="iconfont ali-biyan"></i></div>';
    $output .= '</div>';
    $output .= '<div class="error-tip"><span hidden="">Nhập mật khẩu</span></div>';
    $output .= '</div>';
    $output .= '<div class="remeber-box"><img class="gou" src="<?php echo get_template_directory_uri(); ?>/assets/images/gou.png"> <span';
    $output .= 'class="login-agree">Ghi nhớ đăng nhập</span></div>';
    $output .= '<div class="bottom"><input class="submit left-submit" type="submit" value="Đăng nhập">';
    $output .= '<div class="right-btn"><span class="register-jump">Đăng ký</span></div>';
    $output .= '</div>';
    $output .= '</div>';
    $output .= '</section>';
    $output .= '</div>';
    $output .= '</div>';

    return $output;
}
add_shortcode( 'soco-user-forms-login', 'soco_login_form' );

// [my_register_form]
// [my_login_form]

// Handle user registration and login form submissions
function soco_handle_user_form() {
    if ( isset( $_POST['register'] ) ) {
        $username = sanitize_user( $_POST['username'] );
        $email = sanitize_email( $_POST['email'] );
        $password = sanitize_text_field( $_POST['password'] );

        // Create the user account
        $user_id = wp_create_user( $username, $password, $email );

        if ( is_wp_error( $user_id ) ) {
            // Display an error message
            wp_die( $user_id->get_error_message() );
        } else {
            // Generate an activation key and save it to the user meta
            $activation_key = md5( $username . time() );
            add_user_meta( $user_id, 'activation_key', $activation_key );

            // Send an email to the user with the activation link
            $to = $email;
            $subject = 'Activate your account';
            $message = 'Click the following link to activate your account: ' . home_url( '/activate?key=' . $activation_key );
            $headers = array( 'Content-Type: text/html; charset=UTF-8' );
            wp_mail( $to, $subject, $message, $headers );

            // Redirect to the homepage
            wp_redirect( home_url() );
            exit;
        }
    } elseif ( isset( $_POST['login'] ) ) {
        $username = sanitize_user( $_POST['username'] );
        $password = sanitize_text_field( $_POST['password'] );

        // Try to log the user in
        $creds = array(
            'user_login'    => $username,
            'user_password' => $password,
            'remember'      => true
        );
        $user = wp_signon( $creds, false );

        if ( is_wp_error( $user ) ) {
            // Display an error message
            wp_die( 'Invalid username or password.' );
        } else {
            // Redirect to the homepage
            wp_redirect( home_url() );
            exit;
        }
    }
}
add_action( 'init', 'soco_handle_user_form' );


// Handle user activation
function soco_handle_activation() {
    if ( isset( $_GET['key'] ) ) {
        $key = sanitize_text_field( $_GET['key'] );

        // Check if the activation key is valid
        $user_query = new WP_User_Query( array(
            'meta_key' => 'activation_key',
            'meta_value' => $key,
            'fields' => 'ID'
        ) );
        $user_ids = $user_query->get_results();

        if ( !empty( $user_ids ) ) {
            // Activate the user account
            $user_id = $user_ids[0];
            delete_user_meta( $user_id, 'activation_key' );
            update_user_meta( $user_id, 'activated', true );

            // Redirect to the login page
            wp_redirect( home_url( '/login' ) );
            exit;
        } else {
            // Display an error message
            wp_die( 'Invalid activation key.' );
        }
    }
}
add_action( 'template_redirect', 'soco_handle_activation' );

    
        
