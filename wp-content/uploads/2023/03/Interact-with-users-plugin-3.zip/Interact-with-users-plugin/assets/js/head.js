(window.webpackJsonp = window.webpackJsonp || []).push([
    [13], {
        177: function(e, t, n) {
            e.exports = n(178)
        },
        178: function(e, t) {
            function n(e) {
                return location.hostname === e || location.hostname === "www." + e || location.hostname === "m." + e
            }
            console.log("head start"), (n("857zb1.com") || n("857zb2.com") || n("857zb1.tv")) && (document.querySelector("title").innerText = "857直播-足球直播-NBA直播-专业体育赛事直播平台", document.querySelector("meta[name=description]").setAttribute("content", "857直播官网提供最新足球直播、英超直播、德甲直播、西甲直播、意甲直播、法甲直播、篮球直播 NBA直播 世界杯直播等体育赛事。24小时不间断更新直播信号，无需亲临现场即可观看高清视频直播")), (n("yyzb1.tv") || n("zb.yuyantv.cn")) && (document.querySelector("title").innerText = "雨燕直播-专业体育赛事直播平台", document.querySelector("meta[name=description]").setAttribute("content", "雨燕直播")), console.log("head end")
        }
    },
    [
        [177, 0]
    ]
]);