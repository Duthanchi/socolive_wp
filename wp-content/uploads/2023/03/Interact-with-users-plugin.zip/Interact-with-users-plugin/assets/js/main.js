// $(document).ready(function() {
// 	$(window).scroll(function() {
// 		if ($(this).scrollTop() > 1){ 
// 			$('.navbar').addClass("sticky");
// 		}
// 		else{
// 			log.console('No');
// 			$('.navbar').removeClass("sticky");
// 		}
// 	});

// });