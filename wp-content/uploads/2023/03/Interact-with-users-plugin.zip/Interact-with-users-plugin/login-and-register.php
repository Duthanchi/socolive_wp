<?php
/*
Plugin Name: Registration, Login and Chat Plugin
Description: A plugin that adds user registration, login and chat functionality to WordPress.
Version: 1.0
Author: Luke
Author URI: 
License: GPL2
*/

// Add registration and login forms to WordPress pages
function soco_registration_form() {
    $output = '';

    // Registration form
    $output .= '<h3>Register</h3>';
    $output .= '<form id="register-form" action="" method="post">';
    $output .= '<label for="username">Username:</label>';
    $output .= '<input type="text" name="username" id="username" required>';

    $output .= '<label for="email">Email:</label>';
    $output .= '<input type="email" name="email" id="email" required>';

    $output .= '<label for="password">Password:</label>';
    $output .= '<input type="password" name="password" id="password" required>';

    $output .= '<input type="submit" name="register" value="Register">';
    $output .= '</form>';

    // // Login form
    // $output .= '<h3>Login</h3>';
    // $output .= '<form id="login-form" action="" method="post">';
    // $output .= '<label for="username">Username:</label>';
    // $output .= '<input type="text" name="username" id="username" required>';

    // $output .= '<label for="password">Password:</label>';
    // $output .= '<input type="password" name="password" id="password" required>';

    // $output .= '<input type="submit" name="login" value="Login">';
    // $output .= '</form>';

    return $output;
}
add_shortcode( 'soco-user-forms-register', 'soco_registration_form' );


function soco_login_form() {
    $output = '';

    // Registration form
    $output .= '<h3>Register</h3>';
    $output .= '<form id="register-form" action="" method="post">';
    $output .= '<label for="username">Username:</label>';
    $output .= '<input type="text" name="username" id="username" required>';

    $output .= '<label for="email">Email:</label>';
    $output .= '<input type="email" name="email" id="email" required>';

    $output .= '<label for="password">Password:</label>';
    $output .= '<input type="password" name="password" id="password" required>';

    $output .= '<input type="submit" name="register" value="Register">';
    $output .= '</form>';

    // // Login form
    // $output .= '<h3>Login</h3>';
    // $output .= '<form id="login-form" action="" method="post">';
    // $output .= '<label for="username">Username:</label>';
    // $output .= '<input type="text" name="username" id="username" required>';

    // $output .= '<label for="password">Password:</label>';
    // $output .= '<input type="password" name="password" id="password" required>';

    // $output .= '<input type="submit" name="login" value="Login">';
    // $output .= '</form>';

    return $output;
}
add_shortcode( 'soco-user-forms-login', 'soco_login_form' );

// [my_register_form]
// [my_login_form]

// Handle user registration and login form submissions
function my_handle_user_form() {
    if ( isset( $_POST['register'] ) ) {
        $username = sanitize_user( $_POST['username'] );
        $email = sanitize_email( $_POST['email'] );
        $password = sanitize_text_field( $_POST['password'] );

        // Create the user account
        $user_id = wp_create_user( $username, $password, $email );

        if ( is_wp_error( $user_id ) ) {
            // Display an error message
            wp_die( $user_id->get_error_message() );
        } else {
            // Generate an activation key and save it to the user meta
            $activation_key = md5( $username . time() );
            add_user_meta( $user_id, 'activation_key', $activation_key );

            // Send an email to the user with the activation link
            $to = $email;
            $subject = 'Activate your account';
            $message = 'Click the following link to activate your account: ' . home_url( '/activate?key=' . $activation_key );
            $headers = array( 'Content-Type: text/html; charset=UTF-8' );
            wp_mail( $to, $subject, $message, $headers );

            // Redirect to the homepage
            wp_redirect( home_url() );
            exit;
        }
    } elseif ( isset( $_POST['login'] ) ) {
        $username = sanitize_user( $_POST['username'] );
        $password = sanitize_text_field( $_POST['password'] );

        // Try to log the user in
        $creds = array(
            'user_login'    => $username,
            'user_password' => $password,
            'remember'      => true
        );
        $user = wp_signon( $creds, false );

        if ( is_wp_error( $user ) ) {
            // Display an error message
            wp_die( 'Invalid username or password.' );
        } else {
            // Redirect to the homepage
            wp_redirect( home_url() );
            exit;
        }
    }
}
add_action( 'init', 'soco_handle_user_form' );


// Handle user activation
function soco_handle_activation() {
    if ( isset( $_GET['key'] ) ) {
        $key = sanitize_text_field( $_GET['key'] );

        // Check if the activation key is valid
        $user_query = new WP_User_Query( array(
            'meta_key' => 'activation_key',
            'meta_value' => $key,
            'fields' => 'ID'
        ) );
        $user_ids = $user_query->get_results();

        if ( !empty( $user_ids ) ) {
            // Activate the user account
            $user_id = $user_ids[0];
            delete_user_meta( $user_id, 'activation_key' );
            update_user_meta( $user_id, 'activated', true );

            // Redirect to the login page
            wp_redirect( home_url( '/login' ) );
            exit;
        } else {
            // Display an error message
            wp_die( 'Invalid activation key.' );
        }
    }
}
add_action( 'template_redirect', 'soco_handle_activation' );

    
        
