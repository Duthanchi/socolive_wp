<?php
/*
Plugin Name: Registration, Login and Chat Plugin
Description: A plugin that adds user registration, login and chat functionality to WordPress.
Version: 1.0
Author: Luke
Author URI: 
*/

?>

<?php

function login_register_plugin_styles()
{
    wp_enqueue_style('login_register_plugin-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
    wp_enqueue_style('chat_plugin-style', plugin_dir_url(__FILE__) . 'assets/css/chat.css');
}
add_action('wp_enqueue_scripts', 'login_register_plugin_styles');

function login_register_plugin_scripts()
{
    // Enqueue plugin JavaScript
    wp_enqueue_script('login-register-plugin-script-header', plugin_dir_url(__FILE__) . 'assets/js/header.js', array('jquery'), '1.0', true);
    wp_enqueue_script('login-plugin-scripts', plugin_dir_url(__FILE__) . 'assets/js/login.js', array('jquery'), '1.0', true);
    wp_enqueue_script('chat-plugin-scripts', plugin_dir_url(__FILE__) . 'assets/js/chat.js', array('jquery'), '1.0', true);
}
add_action('wp_enqueue_scripts', 'login_register_plugin_scripts', 9999 );

// Add registration and login forms to WordPress pages
function soco_registration_form()
{
    // Registration form
    $output = '<div class="register-window header-window" hidden=""><img class="close"
    src="' . plugin_dir_url( __FILE__ ) . 'assets/images/close.png">
    <div class="window-inner input-container">
    <section class="content type-content">
      <div class="form"><input type="password" autocomplete="new-password" hidden="">
        <div class="form-title">Đăng ký</div>
        <div class="phone-box">
          <div class="input-group">
            <div class="country-code-box"><span class="country-code">+84</span>
              <div class="triangle"></div>
            </div>
            <div class="country-code-list float-clear" hidden="" style="display: none;">
              <ul>
                <li class="country-code-title"><span>A</span></li>
                <li class="country-code-item"><span class="left">Austria</span><span class="right">+43</span></li>
                <li class="country-code-item"><span class="left">Argentina</span><span class="right">+54</span></li>
                <li class="country-code-item"><span class="left">Australia</span><span class="right">+61</span></li>
                <li class="country-code-item"><span class="left">Afghanistan</span><span class="right">+93</span></li>
                <li class="country-code-item"><span class="left">Algeria</span><span class="right">+213</span></li>
                <li class="country-code-item"><span class="left">Angola</span><span class="right">+244</span></li>
                <li class="country-code-item"><span class="left">Ascension</span><span class="right">+247</span></li>
                <li class="country-code-item"><span class="left">Albania</span><span class="right">+355</span></li>
                <li class="country-code-item"><span class="left">Armenia</span><span class="right">+374</span></li>
                <li class="country-code-item"><span class="left">Andorra</span><span class="right">+376</span></li>
                <li class="country-code-item"><span class="left">Azerbaijan</span><span class="right">+994</span></li>
                <li class="country-code-item"><span class="left">Anguilla</span><span class="right">+1264</span></li>
                <li class="country-code-item"><span class="left">Antigua and Barbuda</span><span
                    class="right">+1268</span></li>
                <li class="country-code-title"><span>B</span></li>
                <li class="country-code-item"><span class="left">Belgium</span><span class="right">+32</span></li>
                <li class="country-code-item"><span class="left">Brazil</span><span class="right">+55</span></li>
                <li class="country-code-item"><span class="left">Burkina Faso</span><span class="right">+226</span>
                </li>
                <li class="country-code-item"><span class="left">Benin</span><span class="right">+229</span></li>
                <li class="country-code-item"><span class="left">Burundi</span><span class="right">+257</span></li>
                <li class="country-code-item"><span class="left">Botswana</span><span class="right">+267</span></li>
                <li class="country-code-item"><span class="left">Bulgaria</span><span class="right">+359</span></li>
                <li class="country-code-item"><span class="left">Belarus</span><span class="right">+375</span></li>
                <li class="country-code-item"><span class="left">Belize</span><span class="right">+501</span></li>
                <li class="country-code-item"><span class="left">Bolivia</span><span class="right">+591</span></li>
                <li class="country-code-item"><span class="left">Brunei</span><span class="right">+673</span></li>
                <li class="country-code-item"><span class="left">Bangladesh</span><span class="right">+880</span></li>
                <li class="country-code-item"><span class="left">Bahrain</span><span class="right">+973</span></li>
                <li class="country-code-item"><span class="left">Bahamas</span><span class="right">+1242</span></li>
                <li class="country-code-item"><span class="left">Barbados</span><span class="right">+1246</span></li>
                <li class="country-code-item"><span class="left">Bermuda Islands</span><span
                    class="right">+1441</span></li>
                <li class="country-code-title"><span>C</span></li>
                <li class="country-code-item"><span class="left">Canada</span><span class="right">+1</span></li>
                <li class="country-code-item"><span class="left">Cuba</span><span class="right">+53</span></li>
                <li class="country-code-item"><span class="left">Chile</span><span class="right">+56</span></li>
                <li class="country-code-item"><span class="left">Colombia</span><span class="right">+57</span></li>
                <li class="country-code-item"><span class="left">China</span><span class="right">+86</span></li>
                <li class="country-code-item"><span class="left">Chad</span><span class="right">+235</span></li>
                <li class="country-code-item"><span class="left">Central African Republic</span><span
                    class="right">+236</span></li>
                <li class="country-code-item"><span class="left">Cameroon</span><span class="right">+237</span></li>
                <li class="country-code-item"><span class="left">Congo</span><span class="right">+242</span></li>
                <li class="country-code-item"><span class="left">Cyprus</span><span class="right">+357</span></li>
                <li class="country-code-item"><span class="left">Czech Republic</span><span class="right">+420</span>
                </li>
                <li class="country-code-item"><span class="left">Costa Rica</span><span class="right">+506</span></li>
                <li class="country-code-item"><span class="left">Cook Islands</span><span class="right">+682</span>
                </li>
                <li class="country-code-item"><span class="left">Cambodia </span><span class="right">+855</span></li>
                <li class="country-code-item"><span class="left">Cayman Islands</span><span class="right">+1345</span>
                </li>
                <li class="country-code-title"><span>D</span></li>
                <li class="country-code-item"><span class="left">Denmark</span><span class="right">+45</span></li>
                <li class="country-code-item"><span class="left">Djibouti</span><span class="right">+253</span></li>
                <li class="country-code-item"><span class="left">Dominica Republic</span><span
                    class="right">+1890</span></li>
                <li class="country-code-title"><span>E</span></li>
                <li class="country-code-item"><span class="left">Egypt</span><span class="right">+20</span></li>
                <li class="country-code-item"><span class="left">Ethiopia</span><span class="right">+251</span></li>
                <li class="country-code-item"><span class="left">Estonia</span><span class="right">+372</span></li>
                <li class="country-code-item"><span class="left">EISalvador</span><span class="right">+503</span></li>
                <li class="country-code-item"><span class="left">Ecuador</span><span class="right">+593</span></li>
                <li class="country-code-title"><span>F</span></li>
                <li class="country-code-item"><span class="left">France</span><span class="right">+33</span></li>
                <li class="country-code-item"><span class="left">Finland</span><span class="right">+358</span></li>
                <li class="country-code-item"><span class="left">French Guiana</span><span class="right">+594</span>
                </li>
                <li class="country-code-item"><span class="left">Fiji</span><span class="right">+679</span></li>
                <li class="country-code-item"><span class="left">French Polynesia</span><span
                    class="right">+689</span></li>
                <li class="country-code-title"><span>G</span></li>
                <li class="country-code-item"><span class="left">Greece</span><span class="right">+30</span></li>
                <li class="country-code-item"><span class="left">Germany</span><span class="right">+49</span></li>
                <li class="country-code-item"><span class="left">Gambia</span><span class="right">+220</span></li>
                <li class="country-code-item"><span class="left">Guinea</span><span class="right">+224</span></li>
                <li class="country-code-item"><span class="left">Ghana</span><span class="right">+233</span></li>
                <li class="country-code-item"><span class="left">Gabon</span><span class="right">+241</span></li>
                <li class="country-code-item"><span class="left">Gibraltar</span><span class="right">+350</span></li>
                <li class="country-code-item"><span class="left">Guatemala</span><span class="right">+502</span></li>
                <li class="country-code-item"><span class="left">Guyana</span><span class="right">+592</span></li>
                <li class="country-code-item"><span class="left">Georgia</span><span class="right">+995</span></li>
                <li class="country-code-item"><span class="left">Guam</span><span class="right">+1671</span></li>
                <li class="country-code-item"><span class="left">Grenada</span><span class="right">+1809</span></li>
                <li class="country-code-title"><span>H</span></li>
                <li class="country-code-item"><span class="left">Hungary</span><span class="right">+36</span></li>
                <li class="country-code-item"><span class="left">Honduras</span><span class="right">+504</span></li>
                <li class="country-code-item"><span class="left">Haiti</span><span class="right">+509</span></li>
                <li class="country-code-item"><span class="left">Hong Kong</span><span class="right">+852</span></li>
                <li class="country-code-title"><span>I</span></li>
                <li class="country-code-item"><span class="left">Italy</span><span class="right">+39</span></li>
                <li class="country-code-item"><span class="left">Indonesia</span><span class="right">+62</span></li>
                <li class="country-code-item"><span class="left">India</span><span class="right">+91</span></li>
                <li class="country-code-item"><span class="left">Iran</span><span class="right">+98</span></li>
                <li class="country-code-item"><span class="left">Ivory Coast</span><span class="right">+225</span>
                </li>
                <li class="country-code-item"><span class="left">Ireland</span><span class="right">+353</span></li>
                <li class="country-code-item"><span class="left">Iceland</span><span class="right">+354</span></li>
                <li class="country-code-item"><span class="left">Iraq</span><span class="right">+964</span></li>
                <li class="country-code-item"><span class="left">Israel</span><span class="right">+972</span></li>
                <li class="country-code-title"><span>J</span></li>
                <li class="country-code-item"><span class="left">Japan</span><span class="right">+81</span></li>
                <li class="country-code-item"><span class="left">Jordan</span><span class="right">+962</span></li>
                <li class="country-code-item"><span class="left">Jamaica</span><span class="right">+1876</span></li>
                <li class="country-code-title"><span>K</span></li>
                <li class="country-code-item"><span class="left">South Korea</span><span class="right">+82</span></li>
                <li class="country-code-item"><span class="left">Kenya</span><span class="right">+254</span></li>
                <li class="country-code-item"><span class="left">Kazakstan</span><span class="right">+327</span></li>
                <li class="country-code-item"><span class="left">Kyrgyzstan</span><span class="right">+331</span></li>
                <li class="country-code-item"><span class="left">Kuwait</span><span class="right">+965</span></li>
                <li class="country-code-title"><span>L</span></li>
                <li class="country-code-item"><span class="left">Libya</span><span class="right">+218</span></li>
                <li class="country-code-item"><span class="left">Liberia</span><span class="right">+231</span></li>
                <li class="country-code-item"><span class="left">Lesotho</span><span class="right">+266</span></li>
                <li class="country-code-item"><span class="left">Luxembourg</span><span class="right">+352</span></li>
                <li class="country-code-item"><span class="left">Lithuania</span><span class="right">+370</span></li>
                <li class="country-code-item"><span class="left">Latvia</span><span class="right">+371</span></li>
                <li class="country-code-item"><span class="left">Liechtenstein</span><span class="right">+423</span>
                </li>
                <li class="country-code-item"><span class="left">Laos</span><span class="right">+856</span></li>
                <li class="country-code-item"><span class="left">Lebanon</span><span class="right">+961</span></li>
                <li class="country-code-title"><span>M</span></li>
                <li class="country-code-item"><span class="left">Mexico</span><span class="right">+52</span></li>
                <li class="country-code-item"><span class="left">Malaysia</span><span class="right">+60</span></li>
                <li class="country-code-item"><span class="left">Myanmar</span><span class="right">+95</span></li>
                <li class="country-code-item"><span class="left">Morocco</span><span class="right">+212</span></li>
                <li class="country-code-item"><span class="left">Mali</span><span class="right">+223</span></li>
                <li class="country-code-item"><span class="left">Mauritius</span><span class="right">+230</span></li>
                <li class="country-code-item"><span class="left">Mozambique</span><span class="right">+258</span></li>
                <li class="country-code-item"><span class="left">Madagascar</span><span class="right">+261</span></li>
                <li class="country-code-item"><span class="left">Malawi</span><span class="right">+265</span></li>
                <li class="country-code-item"><span class="left">Malta</span><span class="right">+356</span></li>
                <li class="country-code-item"><span class="left">Moldova</span><span class="right">+373</span></li>
                <li class="country-code-item"><span class="left">Monaco</span><span class="right">+377</span></li>
                <li class="country-code-item"><span class="left">Martinique</span><span class="right">+596</span></li>
                <li class="country-code-item"><span class="left">Macao</span><span class="right">+853</span></li>
                <li class="country-code-item"><span class="left">Maldives</span><span class="right">+960</span></li>
                <li class="country-code-item"><span class="left">Mongolia</span><span class="right">+976</span></li>
                <li class="country-code-item"><span class="left">Montserrat Islands</span><span
                    class="right">+1664</span></li>
                <li class="country-code-item"><span class="left">Mariana Islands</span><span
                    class="right">+1670</span></li>
                <li class="country-code-item"><span class="left">Montenegro</span><span class="right">+382</span></li>
                <li class="country-code-title"><span>N</span></li>
                <li class="country-code-item"><span class="left">Netherlands</span><span class="right">+31</span></li>
                <li class="country-code-item"><span class="left">Norway</span><span class="right">+47</span></li>
                <li class="country-code-item"><span class="left">New Zealand</span><span class="right">+64</span></li>
                <li class="country-code-item"><span class="left">Niger</span><span class="right">+227</span></li>
                <li class="country-code-item"><span class="left">Nigeria</span><span class="right">+234</span></li>
                <li class="country-code-item"><span class="left">Namibia</span><span class="right">+264</span></li>
                <li class="country-code-item"><span class="left">Nicaragua</span><span class="right">+505</span></li>
                <li class="country-code-item"><span class="left">Netherlands Antilles</span><span
                    class="right">+599</span></li>
                <li class="country-code-item"><span class="left">Nauru</span><span class="right">+674</span></li>
                <li class="country-code-item"><span class="left">North Korea</span><span class="right">+850</span>
                </li>
                <li class="country-code-item"><span class="left">Nepal</span><span class="right">+977</span></li>
                <li class="country-code-title"><span>O</span></li>
                <li class="country-code-item"><span class="left">Oman</span><span class="right">+968</span></li>
                <li class="country-code-title"><span>P</span></li>
                <li class="country-code-item"><span class="left">Poland</span><span class="right">+48</span></li>
                <li class="country-code-item"><span class="left">Peru</span><span class="right">+51</span></li>
                <li class="country-code-item"><span class="left">Philippines</span><span class="right">+63</span></li>
                <li class="country-code-item"><span class="left">Pakistan</span><span class="right">+92</span></li>
                <li class="country-code-item"><span class="left">Portugal</span><span class="right">+351</span></li>
                <li class="country-code-item"><span class="left">Panama</span><span class="right">+507</span></li>
                <li class="country-code-item"><span class="left">Paraguay</span><span class="right">+595</span></li>
                <li class="country-code-item"><span class="left">Papua New Cuinea</span><span
                    class="right">+675</span></li>
                <li class="country-code-item"><span class="left">PuertoRico</span><span class="right">+1787</span>
                </li>
                <li class="country-code-title"><span>Q</span></li>
                <li class="country-code-item"><span class="left">Qatar</span><span class="right">+974</span></li>
                <li class="country-code-title"><span>R</span></li>
                <li class="country-code-item"><span class="left">Russia</span><span class="right">+7</span></li>
                <li class="country-code-item"><span class="left">Romania</span><span class="right">+40</span></li>
                <li class="country-code-item"><span class="left">Reunion</span><span class="right">+262</span></li>
                <li class="country-code-title"><span>S</span></li>
                <li class="country-code-item"><span class="left">South Africa</span><span class="right">+27</span>
                </li>
                <li class="country-code-item"><span class="left">Spain</span><span class="right">+34</span></li>
                <li class="country-code-item"><span class="left">Switzerland</span><span class="right">+41</span></li>
                <li class="country-code-item"><span class="left">Sweden</span><span class="right">+46</span></li>
                <li class="country-code-item"><span class="left">Singapore</span><span class="right">+65</span></li>
                <li class="country-code-item"><span class="left">Sri Lanka</span><span class="right">+94</span></li>
                <li class="country-code-item"><span class="left">Senegal</span><span class="right">+221</span></li>
                <li class="country-code-item"><span class="left">Sierra Leone</span><span class="right">+232</span>
                </li>
                <li class="country-code-item"><span class="left">Sao Tome and Principe</span><span
                    class="right">+239</span></li>
                <li class="country-code-item"><span class="left">Seychelles</span><span class="right">+248</span></li>
                <li class="country-code-item"><span class="left">Sudan</span><span class="right">+249</span></li>
                <li class="country-code-item"><span class="left">Somali</span><span class="right">+252</span></li>
                <li class="country-code-item"><span class="left">Swaziland</span><span class="right">+268</span></li>
                <li class="country-code-item"><span class="left">San Marino</span><span class="right">+378</span></li>
                <li class="country-code-item"><span class="left">Slovenia</span><span class="right">+386</span></li>
                <li class="country-code-item"><span class="left">Slovakia</span><span class="right">+421</span></li>
                <li class="country-code-item"><span class="left">Suriname</span><span class="right">+597</span></li>
                <li class="country-code-item"><span class="left">Solomon Islands</span><span class="right">+677</span>
                </li>
                <li class="country-code-item"><span class="left">Samoa Eastern</span><span class="right">+684</span>
                </li>
                <li class="country-code-item"><span class="left">Samoa Western</span><span class="right">+685</span>
                </li>
                <li class="country-code-item"><span class="left">Syria</span><span class="right">+963</span></li>
                <li class="country-code-item"><span class="left">Saudi Arabia</span><span class="right">+966</span>
                </li>
                <li class="country-code-item"><span class="left">Saint Lucia</span><span class="right">+1758</span>
                </li>
                <li class="country-code-item"><span class="left">Saint Vincent</span><span class="right">+1784</span>
                </li>
                <li class="country-code-item"><span class="left">Serbia</span><span class="right">+382</span></li>
                <li class="country-code-title"><span>T</span></li>
                <li class="country-code-item"><span class="left">Thailand</span><span class="right">+66</span></li>
                <li class="country-code-item"><span class="left">Turkey</span><span class="right">+90</span></li>
                <li class="country-code-item"><span class="left">Tunisia</span><span class="right">+216</span></li>
                <li class="country-code-item"><span class="left">Togo</span><span class="right">+228</span></li>
                <li class="country-code-item"><span class="left">Tanzania</span><span class="right">+255</span></li>
                <li class="country-code-item"><span class="left">Tonga</span><span class="right">+676</span></li>
                <li class="country-code-item"><span class="left">Taiwan</span><span class="right">+886</span></li>
                <li class="country-code-item"><span class="left">Tajikstan</span><span class="right">+992</span></li>
                <li class="country-code-item"><span class="left">Turkmenistan</span><span class="right">+993</span>
                </li>
                <li class="country-code-item"><span class="left">Trinidad and Tobago</span><span
                    class="right">+1809</span></li>
                <li class="country-code-title"><span>U</span></li>
                <li class="country-code-item"><span class="left">United States of America</span><span
                    class="right">+1</span></li>
                <li class="country-code-item"><span class="left">United Kiongdom</span><span class="right">+44</span>
                </li>
                <li class="country-code-item"><span class="left">Uzbekistan</span><span class="right">+233</span></li>
                <li class="country-code-item"><span class="left">Uganda</span><span class="right">+256</span></li>
                <li class="country-code-item"><span class="left">Ukraine</span><span class="right">+380</span></li>
                <li class="country-code-item"><span class="left">Uruguay</span><span class="right">+598</span></li>
                <li class="country-code-item"><span class="left">United Arab Emirates</span><span
                    class="right">+971</span></li>
                <li class="country-code-title"><span>V</span></li>
                <li class="country-code-item"><span class="left">Venezuela</span><span class="right">+58</span></li>
                <li class="country-code-item"><span class="left">Vietnam</span><span class="right">+84</span></li>
                <li class="country-code-title"><span>Y</span></li>
                <li class="country-code-item"><span class="left">Yemen</span><span class="right">+967</span></li>
                <li class="country-code-title"><span>Z</span></li>
                <li class="country-code-item"><span class="left">Zaire</span><span class="right">+243</span></li>
                <li class="country-code-item"><span class="left">Zambia</span><span class="right">+260</span></li>
                <li class="country-code-item"><span class="left">Zimbabwe</span><span class="right">+263</span></li>
              </ul>
            </div><input class="input-phone" i18n-placeholder="请输入手机号码" placeholder="Nhập số điện thoại" type="tel"
              maxlength="11">
          </div>
          <div class="error-tip"><span hidden="">Định dạng sai số điện thoại(vd: 987654321)</span></div>
        </div>
        <div class="verify-box" hidden="">
          <div class="input-group"><img class="icon"
              src="' . plugin_dir_url( __FILE__ ) . 'assets/images/password.svg"> <input
              class="input-verify" i18n-placeholder="获取并输入验证码" placeholder="Nhận và nhập mã xác minh" type="tel"
              maxlength="4">
            <div class="btn-verify"><span class="verify-text" i18n-text="获取验证码">Nhận mã xác minh</span></div>
          </div>
          <div class="error-tip"><span i18n-text="请输入4位验证码" hidden="">Nhập 4 ký tự mã xác minh</span></div>
        </div>
        <div class="check-box" hidden="" style="display:none">
          <div class="input-group"><img class="icon"
              src="' . plugin_dir_url( __FILE__ ) . 'assets/images/password.svg"> <input
              class="input-check" i18n-placeholder="请输入图片上的验证码" placeholder="Nhập mã xác minh trong hình" type="text"
              maxlength="5"> <img class="check-img" src="https://socolive10.tv/webApi/api/kaptcha?t=1679981279483&mobile=1"></div>
          <div class="error-tip"><span i18n-text="请输入5位验证码" hidden="">Nhập 5 ký tự mã xác minh</span></div>
        </div>
        <div class="or" style="display:none">Hoặc</div>
        <div class="account-box">
          <div class="input-group"><img class="icon"
              src="' . plugin_dir_url( __FILE__ ) . 'assets/images/user.svg"> <input
              class="input-account" type="text" placeholder="Nhập tên đăng nhập" required=""></div>
          <div class="error-tip"><span hidden="">Nhập tên đăng nhập</span></div>
        </div>
        <div class="captcahr-box" hidden="">
          <div class="input-group"><img class="icon"
              src="' . plugin_dir_url( __FILE__ ) . 'assets/images/password.svg"> <input
              class="input-check" i18n-placeholder="请输入图片上的验证码" placeholder="Nhập mã xác minh trong hình" type="text"
              maxlength="5"> <img class="check-img" src="https://socolive10.tv/webApi/api/kaptcha?t=1679981279483&mobile=1"></div>
          <div class="error-tip"><span i18n-text="请输入5位验证码" hidden="">Nhập 5 ký tự mã xác minh</span></div>
        </div>
        <div class="nickname-box">
          <div class="input-group"><img class="icon"
              src="' . plugin_dir_url( __FILE__ ) . 'assets/images/user.svg"> <input
              class="input-nickname" i18n-placeholder="请输入用户名" placeholder="Đặt biệt danh" type="text" maxlength="15">
          </div>
          <div class="error-tip"><span i18n-text="请输入2~15位用户名" hidden="">Nhập 2~15 ký tự đăng nhập</span></div>
        </div>
        <div class="password-box">
          <div class="input-group"><img class="icon"
              src="' . plugin_dir_url( __FILE__ ) . 'assets/images/password.svg"> <input
              class="input-password" type="password" placeholder="Nhập mật khẩu" required="">
            <div class="eye"><i class="iconfont ali-zhenyan" hidden=""></i> <i class="iconfont ali-biyan"></i></div>
          </div>
          <div class="error-tip"><span hidden="">Nhập mật khẩu</span></div>
        </div>
        <div class="bottom">
          <div class="left-btn"><span class="login-jump">Đăng nhập</span></div><input class="submit right-submit"
            type="submit" value="Đăng ký">
        </div>
      </div>
    </section>
  </div>
</div>';
    return $output;
}

add_shortcode('soco-user-forms-register', 'soco_registration_form');
function soco_login_form()
{
    // Login form
    // <link rel="stylesheet" id="plugin-header-js" href="' . plugin_dir_url( __FILE__ ) . 'assets/js/header.js" type="text/css" media="all">
    $output = '
    <div class="login-window header-window" hidden=""><img class="close"
        src="' . plugin_dir_url( __FILE__ ) . 'assets/images/close.png">
        <div class="window-inner">
            <section class="content type-content">
            <div class="form"><input type="password" autocomplete="new-password" hidden="">
                <div class="form-title">Đăng nhập</div>
                <div class="phone-box">
                <div class="input-group">
                    <div class="country-code-box"><span class="country-code">+84</span>
                    <div class="triangle"></div>
                    </div>
                    <div class="country-code-list float-clear" hidden="" style="display: none;">
                    <ul>
                        <li class="country-code-title"><span>A</span></li>
                        <li class="country-code-item"><span class="left">Austria</span><span class="right">+43</span></li>
                        <li class="country-code-item"><span class="left">Argentina</span><span class="right">+54</span></li>
                        <li class="country-code-item"><span class="left">Australia</span><span class="right">+61</span></li>
                        <li class="country-code-item"><span class="left">Afghanistan</span><span class="right">+93</span></li>
                        <li class="country-code-item"><span class="left">Algeria</span><span class="right">+213</span></li>
                        <li class="country-code-item"><span class="left">Angola</span><span class="right">+244</span></li>
                        <li class="country-code-item"><span class="left">Ascension</span><span class="right">+247</span></li>
                        <li class="country-code-item"><span class="left">Albania</span><span class="right">+355</span></li>
                        <li class="country-code-item"><span class="left">Armenia</span><span class="right">+374</span></li>
                        <li class="country-code-item"><span class="left">Andorra</span><span class="right">+376</span></li>
                        <li class="country-code-item"><span class="left">Azerbaijan</span><span class="right">+994</span></li>
                        <li class="country-code-item"><span class="left">Anguilla</span><span class="right">+1264</span></li>
                        <li class="country-code-item"><span class="left">Antigua and Barbuda</span><span
                            class="right">+1268</span></li>
                        <li class="country-code-title"><span>B</span></li>
                        <li class="country-code-item"><span class="left">Belgium</span><span class="right">+32</span></li>
                        <li class="country-code-item"><span class="left">Brazil</span><span class="right">+55</span></li>
                        <li class="country-code-item"><span class="left">Burkina Faso</span><span class="right">+226</span>
                        </li>
                        <li class="country-code-item"><span class="left">Benin</span><span class="right">+229</span></li>
                        <li class="country-code-item"><span class="left">Burundi</span><span class="right">+257</span></li>
                        <li class="country-code-item"><span class="left">Botswana</span><span class="right">+267</span></li>
                        <li class="country-code-item"><span class="left">Bulgaria</span><span class="right">+359</span></li>
                        <li class="country-code-item"><span class="left">Belarus</span><span class="right">+375</span></li>
                        <li class="country-code-item"><span class="left">Belize</span><span class="right">+501</span></li>
                        <li class="country-code-item"><span class="left">Bolivia</span><span class="right">+591</span></li>
                        <li class="country-code-item"><span class="left">Brunei</span><span class="right">+673</span></li>
                        <li class="country-code-item"><span class="left">Bangladesh</span><span class="right">+880</span></li>
                        <li class="country-code-item"><span class="left">Bahrain</span><span class="right">+973</span></li>
                        <li class="country-code-item"><span class="left">Bahamas</span><span class="right">+1242</span></li>
                        <li class="country-code-item"><span class="left">Barbados</span><span class="right">+1246</span></li>
                        <li class="country-code-item"><span class="left">Bermuda Islands</span><span
                            class="right">+1441</span></li>
                        <li class="country-code-title"><span>C</span></li>
                        <li class="country-code-item"><span class="left">Canada</span><span class="right">+1</span></li>
                        <li class="country-code-item"><span class="left">Cuba</span><span class="right">+53</span></li>
                        <li class="country-code-item"><span class="left">Chile</span><span class="right">+56</span></li>
                        <li class="country-code-item"><span class="left">Colombia</span><span class="right">+57</span></li>
                        <li class="country-code-item"><span class="left">China</span><span class="right">+86</span></li>
                        <li class="country-code-item"><span class="left">Chad</span><span class="right">+235</span></li>
                        <li class="country-code-item"><span class="left">Central African Republic</span><span
                            class="right">+236</span></li>
                        <li class="country-code-item"><span class="left">Cameroon</span><span class="right">+237</span></li>
                        <li class="country-code-item"><span class="left">Congo</span><span class="right">+242</span></li>
                        <li class="country-code-item"><span class="left">Cyprus</span><span class="right">+357</span></li>
                        <li class="country-code-item"><span class="left">Czech Republic</span><span class="right">+420</span>
                        </li>
                        <li class="country-code-item"><span class="left">Costa Rica</span><span class="right">+506</span></li>
                        <li class="country-code-item"><span class="left">Cook Islands</span><span class="right">+682</span>
                        </li>
                        <li class="country-code-item"><span class="left">Cambodia </span><span class="right">+855</span></li>
                        <li class="country-code-item"><span class="left">Cayman Islands</span><span class="right">+1345</span>
                        </li>
                        <li class="country-code-title"><span>D</span></li>
                        <li class="country-code-item"><span class="left">Denmark</span><span class="right">+45</span></li>
                        <li class="country-code-item"><span class="left">Djibouti</span><span class="right">+253</span></li>
                        <li class="country-code-item"><span class="left">Dominica Republic</span><span
                            class="right">+1890</span></li>
                        <li class="country-code-title"><span>E</span></li>
                        <li class="country-code-item"><span class="left">Egypt</span><span class="right">+20</span></li>
                        <li class="country-code-item"><span class="left">Ethiopia</span><span class="right">+251</span></li>
                        <li class="country-code-item"><span class="left">Estonia</span><span class="right">+372</span></li>
                        <li class="country-code-item"><span class="left">EISalvador</span><span class="right">+503</span></li>
                        <li class="country-code-item"><span class="left">Ecuador</span><span class="right">+593</span></li>
                        <li class="country-code-title"><span>F</span></li>
                        <li class="country-code-item"><span class="left">France</span><span class="right">+33</span></li>
                        <li class="country-code-item"><span class="left">Finland</span><span class="right">+358</span></li>
                        <li class="country-code-item"><span class="left">French Guiana</span><span class="right">+594</span>
                        </li>
                        <li class="country-code-item"><span class="left">Fiji</span><span class="right">+679</span></li>
                        <li class="country-code-item"><span class="left">French Polynesia</span><span
                            class="right">+689</span></li>
                        <li class="country-code-title"><span>G</span></li>
                        <li class="country-code-item"><span class="left">Greece</span><span class="right">+30</span></li>
                        <li class="country-code-item"><span class="left">Germany</span><span class="right">+49</span></li>
                        <li class="country-code-item"><span class="left">Gambia</span><span class="right">+220</span></li>
                        <li class="country-code-item"><span class="left">Guinea</span><span class="right">+224</span></li>
                        <li class="country-code-item"><span class="left">Ghana</span><span class="right">+233</span></li>
                        <li class="country-code-item"><span class="left">Gabon</span><span class="right">+241</span></li>
                        <li class="country-code-item"><span class="left">Gibraltar</span><span class="right">+350</span></li>
                        <li class="country-code-item"><span class="left">Guatemala</span><span class="right">+502</span></li>
                        <li class="country-code-item"><span class="left">Guyana</span><span class="right">+592</span></li>
                        <li class="country-code-item"><span class="left">Georgia</span><span class="right">+995</span></li>
                        <li class="country-code-item"><span class="left">Guam</span><span class="right">+1671</span></li>
                        <li class="country-code-item"><span class="left">Grenada</span><span class="right">+1809</span></li>
                        <li class="country-code-title"><span>H</span></li>
                        <li class="country-code-item"><span class="left">Hungary</span><span class="right">+36</span></li>
                        <li class="country-code-item"><span class="left">Honduras</span><span class="right">+504</span></li>
                        <li class="country-code-item"><span class="left">Haiti</span><span class="right">+509</span></li>
                        <li class="country-code-item"><span class="left">Hong Kong</span><span class="right">+852</span></li>
                        <li class="country-code-title"><span>I</span></li>
                        <li class="country-code-item"><span class="left">Italy</span><span class="right">+39</span></li>
                        <li class="country-code-item"><span class="left">Indonesia</span><span class="right">+62</span></li>
                        <li class="country-code-item"><span class="left">India</span><span class="right">+91</span></li>
                        <li class="country-code-item"><span class="left">Iran</span><span class="right">+98</span></li>
                        <li class="country-code-item"><span class="left">Ivory Coast</span><span class="right">+225</span>
                        </li>
                        <li class="country-code-item"><span class="left">Ireland</span><span class="right">+353</span></li>
                        <li class="country-code-item"><span class="left">Iceland</span><span class="right">+354</span></li>
                        <li class="country-code-item"><span class="left">Iraq</span><span class="right">+964</span></li>
                        <li class="country-code-item"><span class="left">Israel</span><span class="right">+972</span></li>
                        <li class="country-code-title"><span>J</span></li>
                        <li class="country-code-item"><span class="left">Japan</span><span class="right">+81</span></li>
                        <li class="country-code-item"><span class="left">Jordan</span><span class="right">+962</span></li>
                        <li class="country-code-item"><span class="left">Jamaica</span><span class="right">+1876</span></li>
                        <li class="country-code-title"><span>K</span></li>
                        <li class="country-code-item"><span class="left">South Korea</span><span class="right">+82</span></li>
                        <li class="country-code-item"><span class="left">Kenya</span><span class="right">+254</span></li>
                        <li class="country-code-item"><span class="left">Kazakstan</span><span class="right">+327</span></li>
                        <li class="country-code-item"><span class="left">Kyrgyzstan</span><span class="right">+331</span></li>
                        <li class="country-code-item"><span class="left">Kuwait</span><span class="right">+965</span></li>
                        <li class="country-code-title"><span>L</span></li>
                        <li class="country-code-item"><span class="left">Libya</span><span class="right">+218</span></li>
                        <li class="country-code-item"><span class="left">Liberia</span><span class="right">+231</span></li>
                        <li class="country-code-item"><span class="left">Lesotho</span><span class="right">+266</span></li>
                        <li class="country-code-item"><span class="left">Luxembourg</span><span class="right">+352</span></li>
                        <li class="country-code-item"><span class="left">Lithuania</span><span class="right">+370</span></li>
                        <li class="country-code-item"><span class="left">Latvia</span><span class="right">+371</span></li>
                        <li class="country-code-item"><span class="left">Liechtenstein</span><span class="right">+423</span>
                        </li>
                        <li class="country-code-item"><span class="left">Laos</span><span class="right">+856</span></li>
                        <li class="country-code-item"><span class="left">Lebanon</span><span class="right">+961</span></li>
                        <li class="country-code-title"><span>M</span></li>
                        <li class="country-code-item"><span class="left">Mexico</span><span class="right">+52</span></li>
                        <li class="country-code-item"><span class="left">Malaysia</span><span class="right">+60</span></li>
                        <li class="country-code-item"><span class="left">Myanmar</span><span class="right">+95</span></li>
                        <li class="country-code-item"><span class="left">Morocco</span><span class="right">+212</span></li>
                        <li class="country-code-item"><span class="left">Mali</span><span class="right">+223</span></li>
                        <li class="country-code-item"><span class="left">Mauritius</span><span class="right">+230</span></li>
                        <li class="country-code-item"><span class="left">Mozambique</span><span class="right">+258</span></li>
                        <li class="country-code-item"><span class="left">Madagascar</span><span class="right">+261</span></li>
                        <li class="country-code-item"><span class="left">Malawi</span><span class="right">+265</span></li>
                        <li class="country-code-item"><span class="left">Malta</span><span class="right">+356</span></li>
                        <li class="country-code-item"><span class="left">Moldova</span><span class="right">+373</span></li>
                        <li class="country-code-item"><span class="left">Monaco</span><span class="right">+377</span></li>
                        <li class="country-code-item"><span class="left">Martinique</span><span class="right">+596</span></li>
                        <li class="country-code-item"><span class="left">Macao</span><span class="right">+853</span></li>
                        <li class="country-code-item"><span class="left">Maldives</span><span class="right">+960</span></li>
                        <li class="country-code-item"><span class="left">Mongolia</span><span class="right">+976</span></li>
                        <li class="country-code-item"><span class="left">Montserrat Islands</span><span
                            class="right">+1664</span></li>
                        <li class="country-code-item"><span class="left">Mariana Islands</span><span
                            class="right">+1670</span></li>
                        <li class="country-code-item"><span class="left">Montenegro</span><span class="right">+382</span></li>
                        <li class="country-code-title"><span>N</span></li>
                        <li class="country-code-item"><span class="left">Netherlands</span><span class="right">+31</span></li>
                        <li class="country-code-item"><span class="left">Norway</span><span class="right">+47</span></li>
                        <li class="country-code-item"><span class="left">New Zealand</span><span class="right">+64</span></li>
                        <li class="country-code-item"><span class="left">Niger</span><span class="right">+227</span></li>
                        <li class="country-code-item"><span class="left">Nigeria</span><span class="right">+234</span></li>
                        <li class="country-code-item"><span class="left">Namibia</span><span class="right">+264</span></li>
                        <li class="country-code-item"><span class="left">Nicaragua</span><span class="right">+505</span></li>
                        <li class="country-code-item"><span class="left">Netherlands Antilles</span><span
                            class="right">+599</span></li>
                        <li class="country-code-item"><span class="left">Nauru</span><span class="right">+674</span></li>
                        <li class="country-code-item"><span class="left">North Korea</span><span class="right">+850</span>
                        </li>
                        <li class="country-code-item"><span class="left">Nepal</span><span class="right">+977</span></li>
                        <li class="country-code-title"><span>O</span></li>
                        <li class="country-code-item"><span class="left">Oman</span><span class="right">+968</span></li>
                        <li class="country-code-title"><span>P</span></li>
                        <li class="country-code-item"><span class="left">Poland</span><span class="right">+48</span></li>
                        <li class="country-code-item"><span class="left">Peru</span><span class="right">+51</span></li>
                        <li class="country-code-item"><span class="left">Philippines</span><span class="right">+63</span></li>
                        <li class="country-code-item"><span class="left">Pakistan</span><span class="right">+92</span></li>
                        <li class="country-code-item"><span class="left">Portugal</span><span class="right">+351</span></li>
                        <li class="country-code-item"><span class="left">Panama</span><span class="right">+507</span></li>
                        <li class="country-code-item"><span class="left">Paraguay</span><span class="right">+595</span></li>
                        <li class="country-code-item"><span class="left">Papua New Cuinea</span><span
                            class="right">+675</span></li>
                        <li class="country-code-item"><span class="left">PuertoRico</span><span class="right">+1787</span>
                        </li>
                        <li class="country-code-title"><span>Q</span></li>
                        <li class="country-code-item"><span class="left">Qatar</span><span class="right">+974</span></li>
                        <li class="country-code-title"><span>R</span></li>
                        <li class="country-code-item"><span class="left">Russia</span><span class="right">+7</span></li>
                        <li class="country-code-item"><span class="left">Romania</span><span class="right">+40</span></li>
                        <li class="country-code-item"><span class="left">Reunion</span><span class="right">+262</span></li>
                        <li class="country-code-title"><span>S</span></li>
                        <li class="country-code-item"><span class="left">South Africa</span><span class="right">+27</span>
                        </li>
                        <li class="country-code-item"><span class="left">Spain</span><span class="right">+34</span></li>
                        <li class="country-code-item"><span class="left">Switzerland</span><span class="right">+41</span></li>
                        <li class="country-code-item"><span class="left">Sweden</span><span class="right">+46</span></li>
                        <li class="country-code-item"><span class="left">Singapore</span><span class="right">+65</span></li>
                        <li class="country-code-item"><span class="left">Sri Lanka</span><span class="right">+94</span></li>
                        <li class="country-code-item"><span class="left">Senegal</span><span class="right">+221</span></li>
                        <li class="country-code-item"><span class="left">Sierra Leone</span><span class="right">+232</span>
                        </li>
                        <li class="country-code-item"><span class="left">Sao Tome and Principe</span><span
                            class="right">+239</span></li>
                        <li class="country-code-item"><span class="left">Seychelles</span><span class="right">+248</span></li>
                        <li class="country-code-item"><span class="left">Sudan</span><span class="right">+249</span></li>
                        <li class="country-code-item"><span class="left">Somali</span><span class="right">+252</span></li>
                        <li class="country-code-item"><span class="left">Swaziland</span><span class="right">+268</span></li>
                        <li class="country-code-item"><span class="left">San Marino</span><span class="right">+378</span></li>
                        <li class="country-code-item"><span class="left">Slovenia</span><span class="right">+386</span></li>
                        <li class="country-code-item"><span class="left">Slovakia</span><span class="right">+421</span></li>
                        <li class="country-code-item"><span class="left">Suriname</span><span class="right">+597</span></li>
                        <li class="country-code-item"><span class="left">Solomon Islands</span><span class="right">+677</span>
                        </li>
                        <li class="country-code-item"><span class="left">Samoa Eastern</span><span class="right">+684</span>
                        </li>
                        <li class="country-code-item"><span class="left">Samoa Western</span><span class="right">+685</span>
                        </li>
                        <li class="country-code-item"><span class="left">Syria</span><span class="right">+963</span></li>
                        <li class="country-code-item"><span class="left">Saudi Arabia</span><span class="right">+966</span>
                        </li>
                        <li class="country-code-item"><span class="left">Saint Lucia</span><span class="right">+1758</span>
                        </li>
                        <li class="country-code-item"><span class="left">Saint Vincent</span><span class="right">+1784</span>
                        </li>
                        <li class="country-code-item"><span class="left">Serbia</span><span class="right">+382</span></li>
                        <li class="country-code-title"><span>T</span></li>
                        <li class="country-code-item"><span class="left">Thailand</span><span class="right">+66</span></li>
                        <li class="country-code-item"><span class="left">Turkey</span><span class="right">+90</span></li>
                        <li class="country-code-item"><span class="left">Tunisia</span><span class="right">+216</span></li>
                        <li class="country-code-item"><span class="left">Togo</span><span class="right">+228</span></li>
                        <li class="country-code-item"><span class="left">Tanzania</span><span class="right">+255</span></li>
                        <li class="country-code-item"><span class="left">Tonga</span><span class="right">+676</span></li>
                        <li class="country-code-item"><span class="left">Taiwan</span><span class="right">+886</span></li>
                        <li class="country-code-item"><span class="left">Tajikstan</span><span class="right">+992</span></li>
                        <li class="country-code-item"><span class="left">Turkmenistan</span><span class="right">+993</span>
                        </li>
                        <li class="country-code-item"><span class="left">Trinidad and Tobago</span><span
                            class="right">+1809</span></li>
                        <li class="country-code-title"><span>U</span></li>
                        <li class="country-code-item"><span class="left">United States of America</span><span
                            class="right">+1</span></li>
                        <li class="country-code-item"><span class="left">United Kiongdom</span><span class="right">+44</span>
                        </li>
                        <li class="country-code-item"><span class="left">Uzbekistan</span><span class="right">+233</span></li>
                        <li class="country-code-item"><span class="left">Uganda</span><span class="right">+256</span></li>
                        <li class="country-code-item"><span class="left">Ukraine</span><span class="right">+380</span></li>
                        <li class="country-code-item"><span class="left">Uruguay</span><span class="right">+598</span></li>
                        <li class="country-code-item"><span class="left">United Arab Emirates</span><span
                            class="right">+971</span></li>
                        <li class="country-code-title"><span>V</span></li>
                        <li class="country-code-item"><span class="left">Venezuela</span><span class="right">+58</span></li>
                        <li class="country-code-item"><span class="left">Vietnam</span><span class="right">+84</span></li>
                        <li class="country-code-title"><span>Y</span></li>
                        <li class="country-code-item"><span class="left">Yemen</span><span class="right">+967</span></li>
                        <li class="country-code-title"><span>Z</span></li>
                        <li class="country-code-item"><span class="left">Zaire</span><span class="right">+243</span></li>
                        <li class="country-code-item"><span class="left">Zambia</span><span class="right">+260</span></li>
                        <li class="country-code-item"><span class="left">Zimbabwe</span><span class="right">+263</span></li>
                    </ul>
                    </div><input class="input-phone" i18n-placeholder="请输入手机号码" placeholder="Nhập số điện thoại" type="tel"
                    maxlength="11">
                </div>
                <div class="error-tip"><span hidden="">Định dạng sai số điện thoại(vd: 987654321)</span></div>
                </div>
                <div class="or">Hoặc</div>
                <div class="account-box">
                <div class="input-group"><img class="icon"
                    src="' . plugin_dir_url( __FILE__ ) . 'assets/images/user.svg"> <input
                    class="input-account" type="text" placeholder="Nhập tên đăng nhập" required=""></div>
                <div class="error-tip"><span hidden="">Nhập tên đăng nhập</span></div>
                </div>
                <div class="password-box">
                <div class="input-group"><img class="icon"
                    src="' . plugin_dir_url( __FILE__ ) . 'assets/images/password.svg"> <input
                    class="input-password" type="password" placeholder="Nhập mật khẩu" required="">
                    <div class="eye"><i class="iconfont ali-zhenyan" hidden=""></i> <i class="iconfont ali-biyan"></i></div>
                </div>
                <div class="error-tip"><span hidden="">Nhập mật khẩu</span></div>
                </div>
                <div class="remeber-box"><img class="gou"
                    src="' . plugin_dir_url( __FILE__ ) . 'assets/images/gou.png"> <span
                    class="login-agree">Ghi nhớ đăng nhập</span></div>
                <div class="bottom"><input class="submit left-submit" type="submit" value="Đăng nhập" id="login">
                <div class="right-btn"><span class="register-jump">Đăng ký</span></div>
                </div>
            </div>
            </section>
        </div>
        </div>';
     return $output;
}
add_shortcode('soco-user-forms-login', 'soco_login_form');


function soco_chat_form()
{
    // Registration form
    $output = '<div class="chat">
    <div class="notice"><span class="notice-title"><img class="notice-icon"
          src="<?php echo get_template_directory_uri(); ?>/assets/images/icon-announcement@2x.png"> <b
          i18n-text="公告"></b> </span><span class="notice-text"></span></div>
    <div class="tab">
      <div class="tab-item tab-active" data-id="0"><span i18n-text="聊天室">Phòng trò chuyện</span></div>
      <!-- <div class="tab-item" data-id="1"><span i18n-text="排行榜">Bảng xếp hạng</span></div> -->
    </div>
    <div class="chat-center" style="height: 534.924px;">
      <div class="chat-panel" id="talkScroll">
        <div class="reconnect-tip" style="display: none;"><img
            src="<?php echo get_template_directory_uri(); ?>/assets/images/loading.gif"> <span>Đang kết
            nối ... vui lòng đợi!</span></div>
        <div class="chat-list z-chat-list" id="chat-list">
          <div>
            <div class="chat-item danmaku-item sys-msg active">
            </div>
          </div>
        </div>
        <div class="gift-effects-wrapper">
        </div>
        <div class="forbidden-user-tip" hidden=""><img class="forbidden-close"
            src="<?php echo get_template_directory_uri(); ?>/assets/images/icon-close.png" alt="关闭">
          <div class="user-msg">
            <div class="user-avatar"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/avatar.png"
                alt="avatar"></div>
            <div class="user-name">***</div>
          </div>
          <div class="user-text" i18n-text="本直播间禁言至">Tắt tiếng phòng live này đến2099/12/12 00:00</div>
          <div class="user-btn" i18n-text="解除禁言" hidden="">Hủy tắt tiếng</div>
        </div>
        <div class="forbidden-tip" hidden=""><img class="forbidden-close"
            src="<?php echo get_template_directory_uri(); ?>/assets/images/icon-close.png" alt="关闭">
          <div class="user-msg">
            <div class="user-avatar"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/avatar.png"
                alt="avatar"></div>
            <div class="user-name">***</div>
          </div>
          <div class="forbidden-select">
            <div class="forbidden-room">
              <div class="forbidden-selected" i18n-text="直播间禁言">Tắt tiếng phòng live<span class="triangle"></span>
              </div>
              <div class="forbidden-select-opt" hidden="">
                <div data-id="0" i18n-text="禁言2小时">Tắt tiếng2Giờ</div>
                <div data-id="1" i18n-text="禁言1天">Tắt tiếng1Ngày</div>
                <div data-id="2">Tắt tiếng3Ngày</div>
                <div data-id="3">Tắt tiếng30Ngày</div>
                <div data-id="4" i18n-text="永久禁言">Vĩnh viễnTắt tiếng</div>
              </div>
            </div>
            <div class="forbidden-all" hidden="">
              <div class="forbidden-selected" i18n-text="全站禁言">Tắt tiếng toàn bộ<span class="triangle"></span>
              </div>
              <div class="forbidden-select-opt" hidden="">
                <div data-id="0" i18n-text="禁言2小时">Tắt tiếng2Giờ</div>
                <div data-id="1" i18n-text="禁言1天">Tắt tiếng1Ngày</div>
                <div data-id="2">Tắt tiếng3Ngày</div>
                <div data-id="3">Tắt tiếng30Ngày</div>
                <div data-id="4" i18n-text="永久禁言">Vĩnh viễnTắt tiếng</div>
              </div>
            </div>
          </div>
        </div>
        <div class="forbidden-sure-tip" hidden=""><img class="forbidden-sure-close"
            src="<?php echo get_template_directory_uri(); ?>/assets/images/icon-close.png" alt="关闭">
          <div class="forbidden-sure-text" i18n-text="将该用户在全站禁言30天吗？">Người dùng này trong toàn bộ trang <span>Tắt
              tiếng30Ngày</span> Đúng không ？</div>
          <div class="forbidden-sure-btn" i18n-text="确定">Xác nhận</div>
        </div>
        <div class="dele-msg" i18n-text="删除" data-id="">Xóa</div>
        <div class="newMsg-tips" hidden=""><span i18n-text="底部有新消息">Tin nhắn ở dưới cùng</span></div>
      </div>
      <div class="rank-list" hidden="">
        <ul hidden=""></ul>
        <div class="rank-list-null" i18n-text="还没有人给主播送贡献值呀！！" hidden="">Chưa có ai đóng góp cho bình luận viên
          nữa！！</div>
      </div>
      <div class="private-chat-btn" i18n-text="私信" hidden="">Trò chuyện riêng</div>
    </div>
    <div class="chat-bottom">
      <div class="gift-option">
        <div class="gift">
          <div class="gift-list">
            <div class="gift-item">
              <img src=""
                class="gift-icon">
              <div class="gift-block ts-dot arrow-bottom an-scale-in-ease">
                <div class="subbox">
                  <div class="gift-msg">
                    <img class="gift-img"
                      src="">
                    <div class="gift-text">
                      <div class="gift-name">TV</div>
                      <div class="gift-number" data-number="50">50 điểm</div>
                    </div>
                  </div>
                  <div class="send-button" data-id="5" i18n-text="赠送">Tặng</div>
                </div>
              </div>
            </div>
            <div class="gift-item">
              <img src="<?php echo get_template_directory_uri(); ?>/assets/images/5a8a2ca78b4e45c66608bef7dbf92f53"
                class="gift-icon">
              <div class="gift-block ts-dot arrow-bottom an-scale-in-ease">
                <div class="subbox">
                  <div class="gift-msg">
                    <img class="gift-img"
                      src="<?php echo get_template_directory_uri(); ?>/assets/images/5a8a2ca78b4e45c66608bef7dbf92f53">
                    <div class="gift-text">
                      <div class="gift-name">Kho báu</div>
                      <div class="gift-number" data-number="100">100 điểm</div>
                    </div>
                  </div>
                  <div class="send-button" data-id="6" i18n-text="赠送">Tặng</div>
                </div>
              </div>
            </div>
            <div class="gift-item">
              <img src="<?php echo get_template_directory_uri(); ?>/assets/images/33a04170cb9f482bcf50cdd6859d986e"
                class="gift-icon">
              <div class="gift-block ts-dot arrow-bottom an-scale-in-ease">
                <div class="subbox">
                  <div class="gift-msg">
                    <img class="gift-img"
                      src="<?php echo get_template_directory_uri(); ?>/assets/images/33a04170cb9f482bcf50cdd6859d986e">
                    <div class="gift-text">
                      <div class="gift-name">Hỏa tiễn</div>
                      <div class="gift-number" data-number="200">200 điểm</div>
                    </div>
                  </div>
                  <div class="send-button" data-id="7" i18n-text="赠送">Tặng</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="integral">
          <p class="integral-content"><span class="integral-num">0 </span><span class="integral-name"
              i18n-text="我的金币">Điểm của tôi</span></p><span class="get-integral" i18n-text="如何获取金币">Hướng dẫn nhận
            điểm</span>
        </div>
      </div>
      <div class="option"><a href="javascript:;" class="emoji"></a>
        <div class="emoji-panel">
          <div class="browBox">
            <ul>
              <li data-id="grinning">😀</li>
              <li data-id="grin">😁</li>
              <li data-id="smiley">😃</li>
              <li data-id="smile">😄</li>
              <li data-id="sweat_smile">😅</li>
              <li data-id="laughing">😆</li>
              <li data-id="innocent">😇</li>
              <li data-id="wink">😉</li>
              <li data-id="blush">😊</li>
              <li data-id="slightly_smiling_face">🙂</li>
              <li data-id="yum">😋</li>
              <li data-id="heart_eyes">😍</li>
              <li data-id="kissing_heart">😘</li>
              <li data-id="kissing">😗</li>
              <li data-id="kissing_smiling_eyes">😙</li>
              <li data-id="kissing_closed_eyes">😚</li>
              <li data-id="stuck_out_tongue_winking_eye">😜</li>
              <li data-id="stuck_out_tongue_closed_eyes">😝</li>
              <li data-id="stuck_out_tongue">😛</li>
              <li data-id="sunglasses">😎</li>
              <li data-id="roll_eyes">🙄</li>
              <li data-id="flushed">😳</li>
              <li data-id="rage">😡</li>
              <li data-id="confused">😕</li>
              <li data-id="tired_face">😫</li>
              <li data-id="triumph">😤</li>
              <li data-id="fearful">😨</li>
              <li data-id="disappointed_relieved">😥</li>
              <li data-id="sleepy">😪</li>
              <li data-id="sweat">😓</li>
              <li data-id="dizzy_face">😵</li>
              <li data-id="astonished">😲</li>
              <li data-id="sneezing_face">🤧</li>
              <li data-id="mask">😷</li>
              <li data-id="face_with_thermometer">🤒</li>
              <li data-id="face_with_head_bandage">🤕</li>
              <li data-id="sleeping">😴</li>
              <li data-id="zzz">💤</li>
              <li data-id="clap">👏</li>
              <li data-id="call_me_hand">🤙</li>
              <li data-id="+1">👍</li>
              <li data-id="-1">👎</li>
              <li data-id="facepunch">👊</li>
              <li data-id="fist">✊</li>
              <li data-id="v">✌</li>
              <li data-id="ok_hand">👌</li>
              <li data-id="raised_hand">✋</li>
              <li data-id="raised_back_of_hand">🤚</li>
              <li data-id="muscle">💪</li>
              <li data-id="handshake">🤝</li>
              <li data-id="point_left">👈</li>
              <li data-id="point_right">👉</li>
              <li data-id="fu">🖕</li>
              <li data-id="raised_hand_with_fingers_splayed">🖐</li>
              <li data-id="lips">👄</li>
              <li data-id="ear">👂</li>
              <li data-id="eyes">👀</li>
              <li data-id="santa">🎅</li>
              <li data-id="sun_with_face">🌞</li>
              <li data-id="crescent_moon">🌙</li>
              <li data-id="star">⭐</li>
              <li data-id="zap">⚡</li>
              <li data-id="fire">🔥</li>
              <li data-id="snowflake">❄️</li>
              <li data-id="soccer">⚽</li>
              <li data-id="basketball">🏀</li>
              <li data-id="football">🏈</li>
              <li data-id="baseball">⚾</li>
              <li data-id="gift">🎁</li>
              <li data-id="tada">🎉</li>
              <li data-id="black_nib">✒️</li>
              <li data-id="memo">📝</li>
              <li data-id="heart">❤️</li>
              <li data-id="yellow_heart">💛</li>
              <li data-id="green_heart">💚</li>
              <li data-id="vs">🆚</li>
              <li data-id="speech_balloon">💬</li>
              <li data-id="clock1">🕐</li>
            </ul>
          </div><b class="arrow-down pa"></b>
        </div>
        <div class="shield"><a href="javascript:;" class="danmu"></a>
          <div class="shield-checkbox">
            <div class="checkbox"><input type="checkbox" name="shieldCheckbox" id="CheckboxAll" value="0"
                class="input-check"> <label for="CheckboxAll" i18n-text="全部屏蔽">Chặn tất cả</label></div>
            <div class="checkbox"><input type="checkbox" name="shieldCheckbox" id="CheckboxGift" value="1"
                class="input-check"> <label for="CheckboxGift" i18n-text="屏蔽礼物动画">Chặn hình quà tặng</label></div>
            <div class="checkbox"><input type="checkbox" name="shieldCheckbox" id="CheckboxWc" value="2"
                class="input-check"> <label for="CheckboxWc" i18n-text="屏蔽进场欢迎">Chặn lời chào</label></div>
          </div>
        </div>
        <div class="inputBox">
          <div class="noLogin" i18n-text="登录后才可以发送消息哦~~"><span>Đăng nhập</span> để cùng chat nhé~~</div>
          <div hidden="" id="textarea" class="textarea-box">
            <div class="textarea" contenteditable="true" placeholder="Cùng comment vui vẻ nhé ~~"></div>
            <div class="count-box"><span class="text-count">0</span>/120</div>
          </div>
          <div class="send" i18n-text="发送">Gửi</div>
        </div>
      </div>
    </div>
  </div>';
    return $output;
}
add_shortcode('soco_chat_form', 'soco_chat_form');
?>

